Page({
  //监听页面显示
  onShow: function () {
      //自动跳转到index
setTimeout(function () {
  // wx.redirectTo({
  // url: '../index/index'
  // })
  //navigateTo
  wx.reLaunch({
  url: '../index/index'
  })
  }, 2000)
    },
  })
  