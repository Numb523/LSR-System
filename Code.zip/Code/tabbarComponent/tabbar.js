// tabBarComponent/tabBar.js
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    tabbar: {
      type: Object,
      value: {
        "backgroundColor": "#ffffff",
        "color": "#979795",
        "selectedColor": "#1c1c1b",
        "list": [
          {
            "pagePath": "/pages/index/index",
            "iconPath": "icon/icon_home.png",
            "selectedIconPath": "icon/icon_home_HL.png",
            "text": "首页"
          },
          {
            "pagePath": "pages/sweep/sweep",
            "iconPath": "/tabbarComponent/icon/icon_scan.png",
            "isSpecial": true,
            "text": ""
          },
          {
            "pagePath": "pages/mine/mine",
            "iconPath": "/tabbarComponent/icon/icon_mine.png",
            "selectedIconPath": "/tabbarComponent/icon/icon_mine_HL.png",
            "text": "我的"
          }
        ]
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    // isIphoneX: app.globalData.systemInfo.model == "iPhone X" ? true : false,
  },
  /**
   * 组件的方法列表
   */
  // methods: {
  //   shareTherelease:{
  //     wx.navigateTo({
  //       url: '',
  //     })
  //   }
  // },
  methods: {
    shareTherelease(e) {
      console.log(e.currentTarget.dataset.url);
      // wx.navigateTo({
      //   url: e.currentTarget.dataset.url
      // })
    }
  },
  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset
      const index=e.currentTarget.index
      if(index==1){
        // 只允许从相机扫码
wx.scanCode({
  onlyFromCamera: true,
  success (res) {
    console.log(res)
  }
})
      }else{
        const url = data.path
        wx.switchTab({ url })
      }
      this.setData({
        selected:data.index
      })
    }
  }
})
